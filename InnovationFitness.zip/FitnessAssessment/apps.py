from django.apps import AppConfig


class FitnessassessmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'FitnessAssessment'
    verbose_name = "Fitness Assessment"
        
